const cloudinary = require("../config/cloudinary");
const Job = require("../models/Job");
const Application = require("../models/Application");

// Create Job
exports.createJob = async (req, res) => {
  try {
    let image = {};
    if (req.file) {
      const result = await cloudinary.uploader.upload(req.file.path, {
        folder: "jobs"
      });
      image = { url: result.secure_url, publicId: result.public_id };
    }

    const job = await Job.create({
      employer: req.user.id,
      title: req.body.title,
      description: req.body.description,
      category: req.body.category,
      location: req.body.location,
      rate: req.body.rate,
      duration: req.body.duration,
      urgent: req.body.urgent === 'true',
      image
    });

    res.json({ success: true, job });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// Get All Jobs (For Employees)
exports.getAllJobs = async (req, res) => {
  try {
    const { category, search, location } = req.query;
    
    let filter = { status: 'active' };
    
    if (category && category !== 'all') {
      filter.category = category;
    }
    
    if (search) {
      filter.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } }
      ];
    }
    
    if (location) {
      filter.location = { $regex: location, $options: 'i' };
    }

    const jobs = await Job.find(filter)
      .populate('employer', 'fullName companyName')
      .sort({ urgent: -1, createdAt: -1 })
      .limit(50);

    res.json({ success: true, jobs });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// Get Employer's Jobs
exports.getEmployerJobs = async (req, res) => {
  try {
    const jobs = await Job.find({ employer: req.user.id })
      .sort({ createdAt: -1 });

    res.json({ success: true, jobs });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// Apply for Job
exports.applyForJob = async (req, res) => {
  try {
    const { jobId, coverLetter, proposedRate } = req.body;

    // Check if job exists
    const job = await Job.findById(jobId);
    if (!job) {
      return res.status(404).json({ success: false, message: 'Job not found' });
    }

    // Check if already applied
    const existingApplication = await Application.findOne({
      jobId,
      employeeId: req.user.id
    });

    if (existingApplication) {
      return res.status(400).json({ 
        success: false, 
        message: 'You have already applied for this job' 
      });
    }

    // Create application
    const application = await Application.create({
      jobId,
      employeeId: req.user.id,
      employerId: job.employer,
      coverLetter,
      proposedRate
    });

    res.json({ success: true, application });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// Get Employee's Applications
exports.getMyApplications = async (req, res) => {
  try {
    const applications = await Application.find({ employeeId: req.user.id })
      .populate('jobId')
      .populate('employerId', 'fullName companyName')
      .sort({ appliedAt: -1 });

    res.json({ success: true, applications });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// Get Applications for Employer's Jobs
exports.getJobApplications = async (req, res) => {
  try {
    const { jobId } = req.params;

    const applications = await Application.find({ 
      jobId,
      employerId: req.user.id 
    })
      .populate('employeeId', 'fullName email phone skills hourlyRate')
      .sort({ appliedAt: -1 });

    res.json({ success: true, applications });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// Update Application Status
exports.updateApplicationStatus = async (req, res) => {
  try {
    const { applicationId } = req.params;
    const { status } = req.body;

    const application = await Application.findOneAndUpdate(
      { _id: applicationId, employerId: req.user.id },
      { status, respondedAt: new Date() },
      { new: true }
    );

    if (!application) {
      return res.status(404).json({ success: false, message: 'Application not found' });
    }

    res.json({ success: true, application });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};