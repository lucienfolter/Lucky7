const User = require('../models/User');

// Get Current User Profile
exports.getProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    res.json({ success: true, user: user.getPublicProfile() });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// Update Profile
exports.updateProfile = async (req, res) => {
  try {
    const allowedFields = [
      'fullName', 'phone', 'location', 'dateOfBirth', 'gender',
      'skills', 'experience', 'hourlyRate', 'bio', 'categories',
      'availability', 'companyName', 'companyType', 'gstin'
    ];

    const updates = {};
    Object.keys(req.body).forEach(key => {
      if (allowedFields.includes(key)) {
        updates[key] = req.body[key];
      }
    });

    const user = await User.findByIdAndUpdate(
      req.user.id,
      updates,
      { new: true, runValidators: true }
    );

    res.json({ success: true, user: user.getPublicProfile() });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};