const mongoose = require('mongoose');

const applicationSchema = new mongoose.Schema({
  jobId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Job',
    required: true
  },
  employeeId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  employerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  status: {
    type: String,
    enum: ['Applied', 'Accepted', 'Rejected', 'Completed'],
    default: 'Applied'
  },
  coverLetter: String,
  proposedRate: Number,
  appliedAt: {
    type: Date,
    default: Date.now
  },
  respondedAt: Date
}, { timestamps: true });

// Index for faster queries
applicationSchema.index({ employeeId: 1, jobId: 1 });
applicationSchema.index({ employerId: 1 });
applicationSchema.index({ status: 1 });

module.exports = mongoose.model('Application', applicationSchema);