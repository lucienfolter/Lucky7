const router = require("express").Router();
const upload = require("../middleware/upload");
const auth = require("../middleware/auth");
const {
  createJob,
  getAllJobs,
  getEmployerJobs,
  applyForJob,
  getMyApplications,
  getJobApplications,
  updateApplicationStatus
} = require("../controllers/jobsController");

// Job Routes
router.post("/create", auth, upload.single("image"), createJob);
router.get("/all", auth, getAllJobs);
router.get("/employer", auth, getEmployerJobs);

// Application Routes
router.post("/apply", auth, applyForJob);
router.get("/my-applications", auth, getMyApplications);
router.get("/:jobId/applications", auth, getJobApplications);
router.put("/applications/:applicationId", auth, updateApplicationStatus);

module.exports = router;