require("dotenv").config();
const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const http = require("http");
const { Server } = require("socket.io");
const jwt = require("jsonwebtoken");

const verificationRoutes = require("./routes/verification");
const uploadRoutes = require("./routes/upload");
const jobsRoutes = require("./routes/jobs");
const authRoutes = require("./routes/auth");
const profileRoutes = require("./routes/profile");
const messagesRoutes = require("./routes/messages");

const Message = require("./models/Message");

const app = express();
const server = http.createServer(app);

// Socket.IO Setup
const io = new Server(server, {
  cors: {
    origin: process.env.CLIENT_URL || "http://localhost:5173",
    credentials: true
  }
});

app.use(cors({ 
  origin: process.env.CLIENT_URL || "http://localhost:5173", 
  credentials: true 
}));
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log("✅ MongoDB connected"))
  .catch(err => console.error("❌ MongoDB connection error:", err));

// Routes
app.use("/api/verification", verificationRoutes);
app.use("/api/upload", uploadRoutes);
app.use("/api/jobs", jobsRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/profile", profileRoutes);
app.use("/api/messages", messagesRoutes);

app.get("/api/health", (req, res) => res.json({ ok: true }));

// Socket.IO Authentication Middleware
io.use((socket, next) => {
  const token = socket.handshake.auth.token;
  
  if (!token) {
    return next(new Error("Authentication error"));
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    socket.userId = decoded.id;
    next();
  } catch (err) {
    next(new Error("Authentication error"));
  }
});

// Socket.IO Connection
const onlineUsers = new Map();

io.on("connection", (socket) => {
  console.log(`✅ User connected: ${socket.userId}`);
  
  // Store online user
  onlineUsers.set(socket.userId, socket.id);
  
  // Broadcast online status
  io.emit("userOnline", { userId: socket.userId });

  // Join personal room
  socket.join(socket.userId);

  // Send Message
  socket.on("sendMessage", async (data) => {
    try {
      const { receiverId, message } = data;
      const senderId = socket.userId;

      const conversationId = Message.getConversationId(senderId, receiverId);

      const newMessage = await Message.create({
        senderId,
        receiverId,
        message,
        conversationId
      });

      await newMessage.populate('senderId', 'fullName profilePicture');

      // Send to receiver if online
      const receiverSocketId = onlineUsers.get(receiverId);
      if (receiverSocketId) {
        io.to(receiverSocketId).emit("receiveMessage", newMessage);
      }

      // Send back to sender
      socket.emit("messageSent", newMessage);
    } catch (err) {
      socket.emit("messageError", { error: err.message });
    }
  });

  // Typing Indicator
  socket.on("typing", (data) => {
    const receiverSocketId = onlineUsers.get(data.receiverId);
    if (receiverSocketId) {
      io.to(receiverSocketId).emit("userTyping", { 
        senderId: socket.userId 
      });
    }
  });

  socket.on("stopTyping", (data) => {
    const receiverSocketId = onlineUsers.get(data.receiverId);
    if (receiverSocketId) {
      io.to(receiverSocketId).emit("userStoppedTyping", { 
        senderId: socket.userId 
      });
    }
  });

  // Disconnect
  socket.on("disconnect", () => {
    console.log(`❌ User disconnected: ${socket.userId}`);
    onlineUsers.delete(socket.userId);
    io.emit("userOffline", { userId: socket.userId });
  });
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
